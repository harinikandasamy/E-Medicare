export class MedicineClass{

    medicineId:number=0;
    manufactureDate:string=""
    medicineName:string="";
    price:string="";
    description:string="";
    seller:string="";
    status:string="";
    type:string="";
   expdate:string="";
   stock:number=0
    }