import { Addmedicine } from './addmedicine.model';

describe('Addmedicine', () => {
  it('should create an instance', () => {
    expect(new Addmedicine()).toBeTruthy();
  });
});
